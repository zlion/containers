Notice
======

These certificates are copies of the ones from https://github.com/rucio/rucio from the etc/certs directory. If you update them over there with the generate.sh script, don't forget to copy them here as well.
